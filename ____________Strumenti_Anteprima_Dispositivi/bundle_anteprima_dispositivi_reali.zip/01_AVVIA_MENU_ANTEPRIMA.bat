@echo off
cd /d "%~dp0"

echo ============================================================
echo Dojo Yamato - Anteprima dispositivi reali
echo ============================================================
echo.
echo Prima di usare questo comando, verifica che in un altro terminale sia attivo:
echo npm run dev
echo.
echo Avvio menu grafico Python...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp002_lancia_menu_anteprima.ps1"

echo.
echo Se il menu non si e' aperto, controlla che Python sia installato.
pause
