import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import type { User } from '@supabase/supabase-js'
import type { CSSProperties, FormEvent, MouseEvent } from 'react'
import AdminNews from '../components/AdminNews'
import AdminInsegnanti from '../components/AdminInsegnanti'
import AdminTeoria from '../components/AdminTeoria'
import AdminDocumenti from '../components/AdminDocumenti'
import AdminIscritti from '../components/AdminIscritti'
import AdminDifesaPersonale from '../components/AdminDifesaPersonale'
import { ADMIN_EMAIL, isAdmin as checkIsAdmin } from '../lib/permissions'
import { getSignedUrlFromPublicUrl } from '../lib/storageSignedUrl'
import { uploadToR2 } from '../lib/r2UploadClient'
import './AreaUtente.css'

const EVENT_IMAGES_BUCKET = 'event-images'
const EVENT_DOCUMENTS_BUCKET = 'event-documents'

type AdminTab =
  | 'news'
  | 'galleria'
  | 'eventi'
  | 'documenti'
  | 'insegnanti'
  | 'teoria'
  | 'difesa'
  | 'iscritti'

type GalleryAlbum = {
  id: string
  title: string
  description: string | null
  category: string | null
  event_date: string | null
  event_year: number
  cover_image_url: string | null
  visible: boolean
  created_at: string
  signed_cover_url?: string | null
}

type GalleryMedia = {
  id: string
  album_id: string
  image_url: string
  caption: string | null
  sort_order: number
  created_at: string
  media_type: 'image' | 'video' | 'youtube' | 'file' | 'social'
  thumbnail_url: string | null
  video_url: string | null
  signed_image_url?: string | null
  signed_video_url?: string | null
  signed_thumbnail_url?: string | null
}

type EventDocument = {
  id: string
  event_id: string
  title: string
  file_url: string
  file_type: string | null
  created_at: string
}

type DojoEvent = {
  id: string
  title: string
  description: string | null
  location: string | null
  event_date: string | null
  provisional_year: number | null
  provisional_month: number | null
  is_date_provisional: boolean
  image_url: string | null
  external_url: string | null
  external_url_label: string | null
  visible: boolean
  created_at: string
  event_documents?: EventDocument[]
  signed_image_url?: string | null
}

function AreaUtente() {
  const [user, setUser] = useState<User | null>(null)

  const [email, setEmail] = useState('')
  const [confirmEmail, setConfirmEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  const [nome, setNome] = useState('')
  const [cognome, setCognome] = useState('')
  const [phone, setPhone] = useState('')
  const [birthDate, setBirthDate] = useState('')
  const [address, setAddress] = useState('')
  const [city, setCity] = useState('')

  const [privacyAccepted, setPrivacyAccepted] = useState(false)
  const [newsletterOptIn, setNewsletterOptIn] = useState(false)
  const [showRegisterForm, setShowRegisterForm] = useState(false)
  const [message, setMessage] = useState('')

  const [adminTab, setAdminTab] = useState<AdminTab>('news')

  const [albums, setAlbums] = useState<GalleryAlbum[]>([])
  const [media, setMedia] = useState<GalleryMedia[]>([])

  const [albumTitle, setAlbumTitle] = useState('')
  const [albumDescription, setAlbumDescription] = useState('')
  const [albumCategory, setAlbumCategory] = useState('')
  const [albumYear, setAlbumYear] = useState(new Date().getFullYear().toString())
  const [albumDate, setAlbumDate] = useState('')
  const [albumVisible, setAlbumVisible] = useState(true)
  const [editingAlbumId, setEditingAlbumId] = useState<string | null>(null)

  const [selectedAlbumId, setSelectedAlbumId] = useState('')
  const [galleryFiles, setGalleryFiles] = useState<FileList | null>(null)
  const [galleryInputKey, setGalleryInputKey] = useState(0)
  const [albumYearFilter, setAlbumYearFilter] = useState('all')
  const [youtubeUrl, setYoutubeUrl] = useState('')
  const [socialUrl, setSocialUrl] = useState('')
  const [socialPreviewFile, setSocialPreviewFile] = useState<File | null>(null)
  const [socialPreviewInputKey, setSocialPreviewInputKey] = useState(0)

  const [events, setEvents] = useState<DojoEvent[]>([])
  const [eventTitle, setEventTitle] = useState('')
  const [eventDescription, setEventDescription] = useState('')
  const [eventLocation, setEventLocation] = useState('')
  const [eventDate, setEventDate] = useState('')
  const [eventIsProvisional, setEventIsProvisional] = useState(false)
  const [eventProvisionalYear, setEventProvisionalYear] = useState(new Date().getFullYear().toString())
  const [eventProvisionalMonth, setEventProvisionalMonth] = useState('')
  const [eventVisible, setEventVisible] = useState(true)
  const [eventExternalUrl, setEventExternalUrl] = useState('')
  const [eventExternalUrlLabel, setEventExternalUrlLabel] = useState('')
  const [eventImageFile, setEventImageFile] = useState<File | null>(null)
  const [eventDocumentFiles, setEventDocumentFiles] = useState<FileList | null>(null)
  const [editingEventId, setEditingEventId] = useState<string | null>(null)
  const [existingEventImageUrl, setExistingEventImageUrl] = useState<string | null>(null)
  const [eventImageInputKey, setEventImageInputKey] = useState(0)
  const [eventDocsInputKey, setEventDocsInputKey] = useState(0)

  const isAdmin = checkIsAdmin(user)
  const selectedAlbum = albums.find((album) => album.id === selectedAlbumId) ?? null
  const selectedAlbumMedia = selectedAlbumId ? media.filter((item) => item.album_id === selectedAlbumId) : []

  const availableYears = useMemo(() => {
    return Array.from(new Set(albums.map((album) => album.event_year))).sort((a, b) => b - a)
  }, [albums])

  const filteredAlbums = useMemo(() => {
    if (albumYearFilter === 'all') return albums
    return albums.filter((album) => String(album.event_year) === albumYearFilter)
  }, [albums, albumYearFilter])

  async function loadProfile(currentUser: User) {
    const profilePayload = {
      id: currentUser.id,
      email: currentUser.email ?? null,
      role: checkIsAdmin(currentUser) ? 'admin' : 'user',
    }

    await supabase.from('profiles').upsert(profilePayload, { onConflict: 'id' })

    const { data } = await supabase
      .from('profiles')
      .select('nome, cognome, phone, birth_date, address, city, newsletter_opt_in, privacy_accepted')
      .eq('id', currentUser.id)
      .single()

    if (data) {
      setNome(data.nome ?? '')
      setCognome(data.cognome ?? '')
      setPhone(data.phone ?? '')
      setBirthDate(data.birth_date ?? '')
      setAddress(data.address ?? '')
      setCity(data.city ?? '')
      setNewsletterOptIn(Boolean(data.newsletter_opt_in))
      setPrivacyAccepted(Boolean(data.privacy_accepted))
    }
  }

  async function loadAlbums() {
    const { data, error } = await supabase
      .from('gallery_albums')
      .select('id, title, description, category, event_date, event_year, cover_image_url, visible, created_at')
      .order('event_year', { ascending: false })
      .order('event_date', { ascending: false, nullsFirst: false })
      .order('created_at', { ascending: false })

    if (error) {
      setMessage(`Errore caricamento album: ${error.message}`)
      return
    }

    const albumsWithSignedCover = await Promise.all(
      (data ?? []).map(async (album) => ({
        ...album,
        signed_cover_url: await getSignedUrlFromPublicUrl(album.cover_image_url),
      }))
    )

    setAlbums(albumsWithSignedCover)
  }

  async function loadMedia() {
    const { data, error } = await supabase
      .from('gallery_photos')
      .select('id, album_id, image_url, caption, sort_order, created_at, media_type, thumbnail_url, video_url')
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: true })

    if (error) {
      setMessage(`Errore caricamento media: ${error.message}`)
      return
    }

    const mediaWithSignedUrls = await Promise.all(
      (data ?? []).map(async (item) => ({
        ...item,
        signed_image_url: await getSignedUrlFromPublicUrl(item.image_url),
        signed_video_url: await getSignedUrlFromPublicUrl(item.video_url),
        signed_thumbnail_url: await getSignedUrlFromPublicUrl(item.thumbnail_url),
      }))
    )

    setMedia(mediaWithSignedUrls as GalleryMedia[])
  }

  async function loadEvents() {
    const { data, error } = await supabase
      .from('events')
      .select(`
        id,
        title,
        description,
        location,
        event_date,
        provisional_year,
        provisional_month,
        is_date_provisional,
        image_url,
        external_url,
        external_url_label,
        visible,
        created_at,
        event_documents (
          id,
          event_id,
          title,
          file_url,
          file_type,
          created_at
        )
      `)
      .order('event_date', { ascending: true, nullsFirst: false })
      .order('provisional_year', { ascending: true, nullsFirst: false })
      .order('provisional_month', { ascending: true, nullsFirst: false })

    if (error) {
      setMessage(`Errore caricamento eventi: ${error.message}`)
      return
    }

    const eventsWithSignedImages = await Promise.all(
      (data ?? []).map(async (event) => ({
        ...event,
        signed_image_url: await getSignedUrlFromPublicUrl(event.image_url),
      }))
    )

    setEvents(eventsWithSignedImages as DojoEvent[])
  }

  useEffect(() => {
    async function getUser() {
      const { data } = await supabase.auth.getUser()
      const currentUser = data.user

      setUser(currentUser)

      if (currentUser) {
        loadProfile(currentUser)
      }
    }

    getUser()

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      const currentUser = session?.user ?? null
      setUser(currentUser)

      if (currentUser) {
        loadProfile(currentUser)
      }
    })

    return () => {
      listener.subscription.unsubscribe()
    }
  }, [])

  useEffect(() => {
    if (isAdmin) {
      loadAlbums()
      loadMedia()
      loadEvents()
    }
  }, [isAdmin])

  async function handleSignup(e: FormEvent | MouseEvent<HTMLButtonElement>) {
    e.preventDefault()

    if (!nome.trim() || !cognome.trim()) {
      setMessage('Inserisci nome e cognome')
      return
    }

    if (!birthDate) {
      setMessage('Inserisci la data di nascita')
      return
    }

    if (!phone.trim()) {
      setMessage('Inserisci il numero di telefono')
      return
    }

    if (!address.trim()) {
      setMessage('Inserisci l’indirizzo')
      return
    }

    if (!city.trim()) {
      setMessage('Inserisci la città')
      return
    }

    if (!email.trim() || !confirmEmail.trim()) {
      setMessage('Inserisci e conferma l’indirizzo email')
      return
    }

    if (email.trim().toLowerCase() !== confirmEmail.trim().toLowerCase()) {
      setMessage('Gli indirizzi email non coincidono')
      return
    }

    if (!password.trim() || !confirmPassword.trim()) {
      setMessage('Inserisci e conferma la password')
      return
    }

    if (password !== confirmPassword) {
      setMessage('Le password non coincidono')
      return
    }

    if (password.length < 6) {
      setMessage('La password deve contenere almeno 6 caratteri')
      return
    }

    if (!privacyAccepted) {
      setMessage('Devi accettare la privacy policy per registrarti')
      return
    }

    setMessage('Registrazione in corso...')

    const cleanEmail = email.trim().toLowerCase()

    const { data, error } = await supabase.auth.signUp({
      email: cleanEmail,
      password,
      options: {
        data: {
          nome: nome.trim(),
          cognome: cognome.trim(),
          phone: phone.trim(),
          birth_date: birthDate,
          address: address.trim(),
          city: city.trim(),
          newsletter_opt_in: newsletterOptIn,
          privacy_accepted: privacyAccepted,
          role: 'user',
        },
      },
    })

    if (error) {
      setMessage(error.message)
      return
    }

    if (data.user) {
      const profilePayload = {
        id: data.user.id,
        email: cleanEmail,
        nome: nome.trim(),
        cognome: cognome.trim(),
        phone: phone.trim(),
        birth_date: birthDate,
        address: address.trim(),
        city: city.trim(),
        role: cleanEmail === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'user',
        newsletter_opt_in: newsletterOptIn,
        privacy_accepted: privacyAccepted,
      }

      await supabase.from('profiles').upsert(profilePayload, { onConflict: 'id' })

      if (newsletterOptIn) {
        await supabase.from('newsletter_subscribers').upsert(
          {
            user_id: data.user.id,
            email: cleanEmail,
            nome: nome.trim(),
            cognome: cognome.trim(),
            active: true,
            consent_newsletter: true,
            consent_privacy: true,
          },
          { onConflict: 'email' }
        )
      }
    }

    setNome('')
    setCognome('')
    setPhone('')
    setBirthDate('')
    setAddress('')
    setCity('')
    setEmail('')
    setConfirmEmail('')
    setPassword('')
    setConfirmPassword('')
    setPrivacyAccepted(false)
    setNewsletterOptIn(false)
    setShowRegisterForm(false)

    setMessage('Registrazione inviata. Controlla la tua email per confermare l’account.')
  }

  async function handleLogin(e: FormEvent) {
    e.preventDefault()
    setMessage('Login...')

    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) setMessage(error.message)
    else setMessage('Login effettuato')
  }

  async function handleLogout() {
    await supabase.auth.signOut()
    setUser(null)
    setMessage('')
  }

  async function handleSaveProfile(e: FormEvent) {
    e.preventDefault()

    if (!user) return

    if (!privacyAccepted) {
      setMessage('Devi accettare la privacy policy')
      return
    }

    const cleanEmail = user.email?.toLowerCase() ?? ''

    const { error } = await supabase
      .from('profiles')
      .update({
        nome: nome.trim(),
        cognome: cognome.trim(),
        phone: phone.trim() || null,
        birth_date: birthDate || null,
        address: address.trim() || null,
        city: city.trim() || null,
        newsletter_opt_in: newsletterOptIn,
        privacy_accepted: privacyAccepted,
        role: checkIsAdmin(user) ? 'admin' : 'user',
      })
      .eq('id', user.id)

    if (error) {
      setMessage(error.message)
      return
    }

    if (newsletterOptIn) {
      await supabase.from('newsletter_subscribers').upsert(
        {
          user_id: user.id,
          email: cleanEmail,
          nome: nome.trim(),
          cognome: cognome.trim(),
          active: true,
          consent_newsletter: true,
          consent_privacy: true,
        },
        { onConflict: 'email' }
      )
    } else {
      await supabase
        .from('newsletter_subscribers')
        .update({ active: false, consent_newsletter: false })
        .eq('email', cleanEmail)
    }

    setMessage('Profilo salvato')
  }

  async function uploadFileToBucket(file: File, bucket: string, folder: string) {
    const fileExt = file.name.split('.').pop()
    const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`
    const filePath = `${folder}/${fileName}`

    const { error: uploadError } = await supabase.storage.from(bucket).upload(filePath, file)

    if (uploadError) throw uploadError

    const { data } = supabase.storage.from(bucket).getPublicUrl(filePath)

    return data.publicUrl
  }

  function resetAlbumForm() {
    setEditingAlbumId(null)
    setAlbumTitle('')
    setAlbumDescription('')
    setAlbumCategory('')
    setAlbumYear(new Date().getFullYear().toString())
    setAlbumDate('')
    setAlbumVisible(true)
  }

  async function handleSaveAlbum(e: FormEvent) {
    e.preventDefault()

    if (!isAdmin) {
      setMessage('Non hai i permessi per gestire la galleria')
      return
    }

    const numericYear = Number(albumYear)

    if (!albumTitle.trim()) {
      setMessage('Inserisci il titolo dell’album')
      return
    }

    if (!numericYear || numericYear < 1900 || numericYear > 2100) {
      setMessage('Inserisci un anno valido')
      return
    }

    setMessage(editingAlbumId ? 'Aggiornamento album...' : 'Creazione album...')

    const payload = {
      title: albumTitle.trim(),
      description: albumDescription.trim() || null,
      category: albumCategory.trim() || null,
      event_year: numericYear,
      event_date: albumDate || null,
      visible: albumVisible,
    }

    if (editingAlbumId) {
      const { error } = await supabase.from('gallery_albums').update(payload).eq('id', editingAlbumId)

      if (error) {
        setMessage(`Errore aggiornamento album: ${error.message}`)
        return
      }

      setMessage('Album aggiornato correttamente')
    } else {
      const { data, error } = await supabase.from('gallery_albums').insert(payload).select('id').single()

      if (error) {
        setMessage(`Errore creazione album: ${error.message}`)
        return
      }

      if (data?.id) setSelectedAlbumId(data.id)
      setMessage('Album creato correttamente')
    }

    resetAlbumForm()
    loadAlbums()
  }

  function handleEditAlbum(album: GalleryAlbum) {
    setEditingAlbumId(album.id)
    setAlbumTitle(album.title)
    setAlbumDescription(album.description ?? '')
    setAlbumCategory(album.category ?? '')
    setAlbumYear(String(album.event_year))
    setAlbumDate(album.event_date ?? '')
    setAlbumVisible(album.visible)
    setAdminTab('galleria')
    setMessage('Modifica album in corso')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function handleManageAlbumMedia(album: GalleryAlbum) {
    setSelectedAlbumId(album.id)
    setAdminTab('galleria')
    setGalleryFiles(null)
    setGalleryInputKey((prev) => prev + 1)
    setMessage(`Gestione contenuti album: ${album.title}`)
  }

  async function handleToggleAlbumVisible(album: GalleryAlbum) {
    const { error } = await supabase
      .from('gallery_albums')
      .update({ visible: !album.visible })
      .eq('id', album.id)

    if (error) {
      setMessage(`Errore aggiornamento visibilità album: ${error.message}`)
      return
    }

    setMessage('Visibilità album aggiornata')
    loadAlbums()
  }

  async function handleDeleteAlbum(albumId: string) {
    const confirmDelete = window.confirm('Vuoi davvero eliminare questo album? Verranno eliminati anche tutti i contenuti collegati.')
    if (!confirmDelete) return

    const { error } = await supabase.from('gallery_albums').delete().eq('id', albumId)

    if (error) {
      setMessage(`Errore eliminazione album: ${error.message}`)
      return
    }

    if (selectedAlbumId === albumId) setSelectedAlbumId('')

    setMessage('Album eliminato')
    loadAlbums()
    loadMedia()
  }

  async function handleUploadAlbumMedia(e: FormEvent) {
    e.preventDefault()

    if (!isAdmin) {
      setMessage('Non hai i permessi per gestire la galleria')
      return
    }

    if (!selectedAlbumId) {
      setMessage('Seleziona un album')
      return
    }

    if (!galleryFiles || galleryFiles.length === 0) {
      setMessage('Seleziona uno o più file')
      return
    }

    const album = albums.find((item) => item.id === selectedAlbumId)

    if (!album) {
      setMessage('Album non trovato')
      return
    }

    setMessage(`Caricamento di ${galleryFiles.length} file...`)

    try {
      const filesArray = Array.from(galleryFiles)
      const currentAlbumMedia = media.filter((item) => item.album_id === selectedAlbumId)
      const startOrder = currentAlbumMedia.length

      const uploadedMedia: {
        album_id: string
        image_url: string
        caption: string | null
        video_url: string | null
        thumbnail_url: string | null
        media_type: 'image' | 'video' | 'file'
        sort_order: number
      }[] = []

      for (let index = 0; index < filesArray.length; index++) {
        const file = filesArray[index]
        const fileName = file.name.toLowerCase()
        const isImage = file.type.startsWith('image/')
        const isVideo = file.type.startsWith('video/')
        const isPdf = file.type === 'application/pdf' || fileName.endsWith('.pdf')

        if (!isImage && !isVideo && !isPdf) {
          setMessage(`File non consentito: ${file.name}. Puoi caricare solo immagini, video o PDF.`)
          return
        }

        const mediaType: 'image' | 'video' | 'file' = isImage ? 'image' : isVideo ? 'video' : 'file'
        const r2Folder = `galleria/${album.event_year}/${selectedAlbumId}`
        const fileUrl = await uploadToR2(file, r2Folder)

        uploadedMedia.push({
          album_id: selectedAlbumId,
          image_url: fileUrl,
          caption: mediaType === 'file' ? file.name : null,
          video_url: isVideo ? fileUrl : null,
          thumbnail_url: null,
          media_type: mediaType,
          sort_order: startOrder + index,
        })
      }

      const { error: insertError } = await supabase.from('gallery_photos').insert(uploadedMedia)

      if (insertError) {
        setMessage(`Errore salvataggio media: ${insertError.message}`)
        return
      }

      const firstImage = uploadedMedia.find((item) => item.media_type === 'image')

      if (!album.cover_image_url && firstImage) {
        await supabase.from('gallery_albums').update({ cover_image_url: firstImage.image_url }).eq('id', selectedAlbumId)
      }

      setGalleryFiles(null)
      setGalleryInputKey((prev) => prev + 1)
      setMessage('File caricati correttamente')
      loadAlbums()
      loadMedia()
    } catch (error) {
      console.error(error)
      setMessage(error instanceof Error ? `Errore durante upload file album: ${error.message}` : 'Errore durante upload file album')
    }
  }

  function getYoutubeId(url: string) {
    const patterns = [
      /youtube\.com\/watch\?v=([^&]+)/,
      /youtu\.be\/([^?&]+)/,
      /youtube\.com\/shorts\/([^?&]+)/,
      /youtube\.com\/embed\/([^?&]+)/,
    ]

    for (const pattern of patterns) {
      const match = url.match(pattern)
      if (match?.[1]) return match[1]
    }

    return null
  }

  async function handleAddYoutubeVideo(e: FormEvent) {
    e.preventDefault()

    if (!isAdmin) {
      setMessage('Non hai i permessi per gestire la galleria')
      return
    }

    if (!selectedAlbumId) {
      setMessage('Seleziona un album')
      return
    }

    const videoId = getYoutubeId(youtubeUrl.trim())

    if (!videoId) {
      setMessage('Inserisci un link YouTube valido')
      return
    }

    const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
    const currentAlbumMedia = media.filter((item) => item.album_id === selectedAlbumId)

    const { error } = await supabase.from('gallery_photos').insert({
      album_id: selectedAlbumId,
      image_url: youtubeUrl.trim(),
      video_url: youtubeUrl.trim(),
      thumbnail_url: thumbnailUrl,
      caption: 'YouTube',
      media_type: 'youtube',
      sort_order: currentAlbumMedia.length,
    })

    if (error) {
      setMessage(`Errore salvataggio video YouTube: ${error.message}`)
      return
    }

    const album = albums.find((item) => item.id === selectedAlbumId)

    if (album && !album.cover_image_url) {
      await supabase.from('gallery_albums').update({ cover_image_url: thumbnailUrl }).eq('id', selectedAlbumId)
    }

    setYoutubeUrl('')
    setMessage('Video YouTube aggiunto correttamente')
    loadAlbums()
    loadMedia()
  }

  function getSocialName(url: string) {
    const lowerUrl = url.toLowerCase()

    if (lowerUrl.includes('facebook.com') || lowerUrl.includes('fb.com')) return 'Facebook'
    if (lowerUrl.includes('instagram.com')) return 'Instagram'
    if (lowerUrl.includes('tiktok.com')) return 'TikTok'

    return null
  }

  async function handleAddSocialLink(e: FormEvent) {
    e.preventDefault()

    if (!isAdmin) {
      setMessage('Non hai i permessi per gestire la galleria')
      return
    }

    if (!selectedAlbumId) {
      setMessage('Seleziona un album')
      return
    }

    const cleanUrl = socialUrl.trim()
    const socialName = getSocialName(cleanUrl)

    if (!cleanUrl || !socialName) {
      setMessage('Inserisci un link valido Facebook, Instagram o TikTok')
      return
    }

    try {
      let previewUrl: string | null = null

      if (socialPreviewFile) {
        if (!socialPreviewFile.type.startsWith('image/')) {
          setMessage('L’anteprima social deve essere un’immagine')
          return
        }

        const album = albums.find((item) => item.id === selectedAlbumId)
        const r2Folder = `galleria/${album?.event_year ?? new Date().getFullYear()}/${selectedAlbumId}/social-previews`
        previewUrl = await uploadToR2(socialPreviewFile, r2Folder)
      }

      const currentAlbumMedia = media.filter((item) => item.album_id === selectedAlbumId)

      const { error } = await supabase.from('gallery_photos').insert({
        album_id: selectedAlbumId,
        image_url: cleanUrl,
        video_url: cleanUrl,
        thumbnail_url: previewUrl,
        caption: socialName,
        media_type: 'social',
        sort_order: currentAlbumMedia.length,
      })

      if (error) {
        setMessage(`Errore salvataggio link social: ${error.message}`)
        return
      }

      setSocialUrl('')
      setSocialPreviewFile(null)
      setSocialPreviewInputKey((prev) => prev + 1)
      setMessage(`Link ${socialName} aggiunto correttamente`)
      loadMedia()
    } catch (error) {
      console.error(error)
      setMessage(error instanceof Error ? `Errore durante salvataggio link social: ${error.message}` : 'Errore durante salvataggio link social')
    }
  }

  async function handleDeleteMedia(item: GalleryMedia) {
    const confirmDelete = window.confirm('Vuoi eliminare questo elemento?')
    if (!confirmDelete) return

    const { error } = await supabase.from('gallery_photos').delete().eq('id', item.id)

    if (error) {
      setMessage(`Errore eliminazione media: ${error.message}`)
      return
    }

    setMessage('Media eliminato')
    loadAlbums()
    loadMedia()
  }

  async function handleSetCover(item: GalleryMedia) {
    const coverUrl =
      item.media_type === 'youtube'
        ? item.thumbnail_url
        : item.media_type === 'image'
          ? item.image_url
          : item.media_type === 'social'
            ? item.thumbnail_url
            : null

    if (!coverUrl) {
      setMessage('Puoi usare come copertina solo immagini, anteprime YouTube o anteprime social')
      return
    }

    const { error } = await supabase.from('gallery_albums').update({ cover_image_url: coverUrl }).eq('id', item.album_id)

    if (error) {
      setMessage(`Errore aggiornamento copertina: ${error.message}`)
      return
    }

    setMessage('Copertina album aggiornata')
    loadAlbums()
  }

  function resetEventForm() {
    setEditingEventId(null)
    setEventTitle('')
    setEventDescription('')
    setEventLocation('')
    setEventDate('')
    setEventIsProvisional(false)
    setEventProvisionalYear(new Date().getFullYear().toString())
    setEventProvisionalMonth('')
    setEventVisible(true)
    setEventExternalUrl('')
    setEventExternalUrlLabel('')
    setEventImageFile(null)
    setEventDocumentFiles(null)
    setExistingEventImageUrl(null)
    setEventImageInputKey((prev) => prev + 1)
    setEventDocsInputKey((prev) => prev + 1)
  }

  async function handleSaveEvent(e: FormEvent) {
    e.preventDefault()

    if (!isAdmin) {
      setMessage('Non hai i permessi per gestire gli eventi')
      return
    }

    if (!eventTitle.trim()) {
      setMessage('Inserisci il titolo evento')
      return
    }

    const provisionalYearNumber = Number(eventProvisionalYear)
    const provisionalMonthNumber = Number(eventProvisionalMonth)

    if (eventIsProvisional) {
      if (!provisionalYearNumber || !provisionalMonthNumber) {
        setMessage('Per una data provvisoria inserisci almeno mese e anno')
        return
      }
    }

    if (!eventDate && !eventIsProvisional) {
      setMessage('Inserisci una data precisa oppure usa data provvisoria')
      return
    }

    setMessage(editingEventId ? 'Aggiornamento evento...' : 'Creazione evento...')

    try {
      let finalImageUrl = existingEventImageUrl

      if (eventImageFile) {
        finalImageUrl = await uploadFileToBucket(eventImageFile, EVENT_IMAGES_BUCKET, 'events')
      }

      const payload = {
        title: eventTitle.trim(),
        description: eventDescription.trim() || null,
        location: eventLocation.trim() || null,
        event_date: eventIsProvisional ? null : eventDate || null,
        provisional_year: eventIsProvisional ? provisionalYearNumber : null,
        provisional_month: eventIsProvisional ? provisionalMonthNumber : null,
        is_date_provisional: eventIsProvisional,
        image_url: finalImageUrl,
        external_url: eventExternalUrl.trim() || null,
        external_url_label: eventExternalUrlLabel.trim() || null,
        visible: eventVisible,
      }

      let eventIdToUse = editingEventId

      if (editingEventId) {
        const { error } = await supabase.from('events').update(payload).eq('id', editingEventId)

        if (error) {
          setMessage(`Errore aggiornamento evento: ${error.message}`)
          return
        }
      } else {
        const { data, error } = await supabase.from('events').insert(payload).select('id').single()

        if (error) {
          setMessage(`Errore creazione evento: ${error.message}`)
          return
        }

        eventIdToUse = data.id
      }

      if (eventIdToUse && eventDocumentFiles && eventDocumentFiles.length > 0) {
        const filesArray = Array.from(eventDocumentFiles)
        const docsToInsert = []

        for (const file of filesArray) {
          const fileUrl = await uploadFileToBucket(file, EVENT_DOCUMENTS_BUCKET, `events/${eventIdToUse}`)

          docsToInsert.push({
            event_id: eventIdToUse,
            title: file.name,
            file_url: fileUrl,
            file_type: file.type || null,
          })
        }

        const { error: docsError } = await supabase.from('event_documents').insert(docsToInsert)

        if (docsError) {
          setMessage(`Evento salvato, ma errore documenti: ${docsError.message}`)
          loadEvents()
          return
        }
      }

      setMessage(editingEventId ? 'Evento aggiornato correttamente' : 'Evento creato correttamente')
      resetEventForm()
      loadEvents()
    } catch (error) {
      console.error(error)
      setMessage('Errore durante salvataggio evento')
    }
  }

  function handleEditEvent(event: DojoEvent) {
    setEditingEventId(event.id)
    setEventTitle(event.title)
    setEventDescription(event.description ?? '')
    setEventLocation(event.location ?? '')
    setEventDate(event.event_date ?? '')
    setEventIsProvisional(event.is_date_provisional)
    setEventProvisionalYear(String(event.provisional_year ?? new Date().getFullYear()))
    setEventProvisionalMonth(String(event.provisional_month ?? ''))
    setEventVisible(event.visible)
    setEventExternalUrl(event.external_url ?? '')
    setEventExternalUrlLabel(event.external_url_label ?? '')
    setExistingEventImageUrl(event.image_url)
    setEventImageFile(null)
    setEventDocumentFiles(null)
    setEventImageInputKey((prev) => prev + 1)
    setEventDocsInputKey((prev) => prev + 1)
    setAdminTab('eventi')
    setMessage('Modifica evento in corso')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  async function handleToggleEventVisible(event: DojoEvent) {
    const { error } = await supabase.from('events').update({ visible: !event.visible }).eq('id', event.id)

    if (error) {
      setMessage(`Errore aggiornamento visibilità evento: ${error.message}`)
      return
    }

    setMessage('Visibilità evento aggiornata')
    loadEvents()
  }

  async function handleDeleteEvent(id: string) {
    const confirmDelete = window.confirm('Vuoi eliminare questo evento? Verranno eliminati anche i documenti collegati.')
    if (!confirmDelete) return

    const { error } = await supabase.from('events').delete().eq('id', id)

    if (error) {
      setMessage(`Errore eliminazione evento: ${error.message}`)
      return
    }

    setMessage('Evento eliminato')
    loadEvents()
  }

  async function handleDeleteEventDocument(id: string) {
    const confirmDelete = window.confirm('Vuoi eliminare questo documento?')
    if (!confirmDelete) return

    const { error } = await supabase.from('event_documents').delete().eq('id', id)

    if (error) {
      setMessage(`Errore eliminazione documento: ${error.message}`)
      return
    }

    setMessage('Documento eliminato')
    loadEvents()
  }

  function formatEventDate(event: DojoEvent) {
    if (event.event_date && !event.is_date_provisional) return new Date(event.event_date).toLocaleDateString('it-IT')

    if (event.provisional_year && event.provisional_month) {
      const date = new Date(event.provisional_year, event.provisional_month - 1, 1)
      return `${date.toLocaleDateString('it-IT', { month: 'long', year: 'numeric' })} provvisoria`
    }

    return 'Data da definire'
  }

  function getAdminAlbumCoverUrl(album: GalleryAlbum) {
    return album.signed_cover_url || album.cover_image_url || ''
  }

  function getAdminMediaPreviewUrl(item: GalleryMedia) {
    if (item.media_type === 'youtube') return item.thumbnail_url || item.image_url
    if (item.media_type === 'video') return item.signed_thumbnail_url || item.thumbnail_url || item.signed_video_url || item.video_url || item.signed_image_url || item.image_url
    if (item.media_type === 'social') return item.signed_thumbnail_url || item.thumbnail_url || item.signed_image_url || item.image_url
    return item.signed_image_url || item.image_url
  }

  function renderTinyMediaPreview(item: GalleryMedia) {
    if (item.media_type === 'youtube') {
      return (
        <div style={tinyMediaPreviewWrapper}>
          <img src={getAdminMediaPreviewUrl(item)} alt="Anteprima YouTube" style={tinyPhotoImage} />
          <span style={videoBadge}>YT</span>
        </div>
      )
    }

    if (item.media_type === 'video') {
      return (
        <div style={tinyMediaPreviewWrapper}>
          <video src={getAdminMediaPreviewUrl(item)} style={tinyPhotoImage} muted />
          <span style={videoBadge}>▶</span>
        </div>
      )
    }

    if (item.media_type === 'file') {
      return (
        <div style={filePreviewStyle}>
          <span style={{ fontSize: '18px', fontWeight: 900 }}>PDF</span>
          <span style={{ fontSize: '8px', fontWeight: 800 }}>DOC</span>
        </div>
      )
    }

    if (item.media_type === 'social') {
      if (item.signed_thumbnail_url || item.thumbnail_url) {
        return (
          <div style={tinyMediaPreviewWrapper}>
            <img src={getAdminMediaPreviewUrl(item)} alt={item.caption || 'Anteprima social'} style={tinyPhotoImage} />
            <span style={socialPreviewBadgeStyle}>{item.caption || 'Social'}</span>
          </div>
        )
      }

      return (
        <div style={socialPreviewFallbackStyle}>
          <span style={{ fontSize: '20px' }}>🔗</span>
          <span style={{ fontSize: '9px', fontWeight: 800 }}>{item.caption || 'SOCIAL'}</span>
        </div>
      )
    }

    return <img src={getAdminMediaPreviewUrl(item)} alt={item.caption || selectedAlbum?.title || 'Media galleria'} style={tinyPhotoImage} />
  }

  if (!user) {
    return (
      <>
        <style>{areaUtenteInlineStyles}</style>

        <div className="auth-page">
          <div className="auth-card">
            <p style={dojoBadgeStyle}>Area riservata</p>
            <h1>Accesso Dojo Yamato</h1>

            <form onSubmit={handleLogin} style={authFormStyle}>
              <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
              <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
              <button className="primary-auth-button" type="submit">Login</button>
            </form>

            <div style={authDividerStyle} />

            <button
              type="button"
              onClick={() => setShowRegisterForm((prev) => !prev)}
              style={registerLinkButtonStyle}
            >
              {showRegisterForm ? 'Chiudi registrazione' : 'Non hai un account? Registrati'}
            </button>

            {showRegisterForm && (
              <>
                <h2 style={{ marginBottom: '8px', marginTop: '22px' }}>Registrazione nuovo utente</h2>
                <p style={mutedText}>Registrandoti potrai accedere ai contenuti riservati, ingrandire e scaricare i media consentiti.</p>

                <form onSubmit={handleSignup} style={authFormStyle}>
                  <div style={twoColumnsStyle}>
                    <input type="text" placeholder="Nome" value={nome} onChange={(e) => setNome(e.target.value)} />
                    <input type="text" placeholder="Cognome" value={cognome} onChange={(e) => setCognome(e.target.value)} />
                  </div>

                  <div style={twoColumnsStyle}>
                    <input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} />
                    <input type="tel" placeholder="Telefono" value={phone} onChange={(e) => setPhone(e.target.value)} />
                  </div>

                  <div style={twoColumnsStyle}>
                    <input type="text" placeholder="Indirizzo" value={address} onChange={(e) => setAddress(e.target.value)} />
                    <input type="text" placeholder="Città" value={city} onChange={(e) => setCity(e.target.value)} />
                  </div>

                  <input type="email" placeholder="Indirizzo email" value={email} onChange={(e) => setEmail(e.target.value)} />
                  <input type="email" placeholder="Conferma indirizzo email" value={confirmEmail} onChange={(e) => setConfirmEmail(e.target.value)} />

                  <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                  <input type="password" placeholder="Conferma password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />

                  <label style={checkboxLabelStyle}>
                    <input type="checkbox" checked={privacyAccepted} onChange={(e) => setPrivacyAccepted(e.target.checked)} />
                    Autorizzo il trattamento dei dati personali secondo la normativa privacy vigente
                  </label>

                  <label style={checkboxLabelStyle}>
                    <input type="checkbox" checked={newsletterOptIn} onChange={(e) => setNewsletterOptIn(e.target.checked)} />
                    Voglio iscrivermi alla newsletter del Dojo Yamato
                  </label>

                  <button className="secondary-auth-button" type="submit">Registrati</button>
                </form>
              </>
            )}

            {message && <p style={{ marginTop: '16px' }}>{message}</p>}
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      <style>{areaUtenteInlineStyles}</style>

      <div className="profile-layout">
        <div className="profile-card">
          <h1>Area Utente</h1>

          <p>Loggato come: <strong>{user.email}</strong></p>
          <p style={mutedText}>Ruolo: <strong>{isAdmin ? 'Admin' : 'User registrato'}</strong></p>

          <form onSubmit={handleSaveProfile} style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginTop: '20px' }}>
            <div style={twoColumnsStyle}>
              <input type="text" placeholder="Nome" value={nome} onChange={(e) => setNome(e.target.value)} />
              <input type="text" placeholder="Cognome" value={cognome} onChange={(e) => setCognome(e.target.value)} />
            </div>

            <div style={twoColumnsStyle}>
              <input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} />
              <input type="tel" placeholder="Telefono" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>

            <div style={twoColumnsStyle}>
              <input type="text" placeholder="Indirizzo" value={address} onChange={(e) => setAddress(e.target.value)} />
              <input type="text" placeholder="Città" value={city} onChange={(e) => setCity(e.target.value)} />
            </div>

            <label style={checkboxLabelStyle}>
              <input type="checkbox" checked={privacyAccepted} onChange={(e) => setPrivacyAccepted(e.target.checked)} />
              Accetto la privacy policy
            </label>

            <label style={checkboxLabelStyle}>
              <input type="checkbox" checked={newsletterOptIn} onChange={(e) => setNewsletterOptIn(e.target.checked)} />
              Iscrivimi alla newsletter
            </label>

            <button className="primary-auth-button" type="submit">Salva profilo</button>
          </form>

          {isAdmin && (
            <section style={adminSectionStyle}>
              <p style={adminLabelStyle}>Pannello amministratore</p>
              <h2 style={{ marginTop: 0 }}>Gestione contenuti sito</h2>

              <div style={tabsWrapper}>
                <button type="button" style={tabButton(adminTab === 'news')} onClick={() => setAdminTab('news')}>News</button>
                <button type="button" style={tabButton(adminTab === 'galleria')} onClick={() => setAdminTab('galleria')}>Galleria</button>
                <button type="button" style={tabButton(adminTab === 'eventi')} onClick={() => setAdminTab('eventi')}>Eventi</button>
                <button type="button" style={tabButton(adminTab === 'documenti')} onClick={() => setAdminTab('documenti')}>Documenti</button>
                <button type="button" style={tabButton(adminTab === 'insegnanti')} onClick={() => setAdminTab('insegnanti')}>Insegnanti</button>
                <button type="button" style={tabButton(adminTab === 'teoria')} onClick={() => setAdminTab('teoria')}>Teoria</button>
                <button type="button" style={tabButton(adminTab === 'difesa')} onClick={() => setAdminTab('difesa')}>Difesa personale</button>
                <button type="button" style={tabButton(adminTab === 'iscritti')} onClick={() => setAdminTab('iscritti')}>Iscritti</button>
              </div>

              {message && adminTab !== 'insegnanti' && adminTab !== 'teoria' && adminTab !== 'documenti' && adminTab !== 'iscritti' && adminTab !== 'difesa' && (
                <div style={messageBox}>{message}</div>
              )}

              {adminTab === 'news' && <AdminNews />}

              {adminTab === 'galleria' && (
                <div>
                  <div style={galleryAdminLayout}>
                    <div style={adminCardStyle}>
                      <h3>{editingAlbumId ? 'Modifica album' : 'Crea nuovo album'}</h3>

                      <form onSubmit={handleSaveAlbum} style={formStyle}>
                        <input type="text" placeholder="Titolo album" value={albumTitle} onChange={(e) => setAlbumTitle(e.target.value)} />
                        <textarea placeholder="Descrizione album" value={albumDescription} onChange={(e) => setAlbumDescription(e.target.value)} rows={4} style={textareaStyle} />
                        <input type="text" placeholder="Categoria, es. Competizioni, Esami, Eventi" value={albumCategory} onChange={(e) => setAlbumCategory(e.target.value)} />
                        <input type="number" placeholder="Anno evento, es. 2026" value={albumYear} onChange={(e) => setAlbumYear(e.target.value)} />

                        <div style={{ display: 'grid', gap: '8px' }}>
                          <label style={mutedText}>Data evento opzionale</label>
                          <input type="date" value={albumDate} onChange={(e) => setAlbumDate(e.target.value)} />
                        </div>

                        <label style={checkboxLabelStyle}>
                          <input type="checkbox" checked={albumVisible} onChange={(e) => setAlbumVisible(e.target.checked)} />
                          Album visibile nella galleria pubblica
                        </label>

                        <div style={actionsRow}>
                          <button className="primary-auth-button" type="submit">{editingAlbumId ? 'Aggiorna album' : 'Crea album'}</button>
                          {editingAlbumId && <button className="secondary-auth-button" type="button" onClick={resetAlbumForm}>Annulla modifica</button>}
                        </div>
                      </form>
                    </div>

                    <div style={adminCardStyle}>
                      <h3>Carica foto, video o PDF</h3>

                      <form onSubmit={handleUploadAlbumMedia} style={formStyle}>
                        <select value={selectedAlbumId} onChange={(e) => setSelectedAlbumId(e.target.value)}>
                          <option value="">Seleziona album</option>
                          {albums.map((album) => <option key={album.id} value={album.id}>{album.event_year} - {album.title}</option>)}
                        </select>

                        <input key={galleryInputKey} type="file" accept="image/*,video/mp4,video/webm,video/quicktime,.pdf" multiple onChange={(e) => setGalleryFiles(e.target.files)} />
                        {galleryFiles && galleryFiles.length > 0 && <small style={mutedText}>File selezionati: {galleryFiles.length}</small>}
                        <button className="primary-auth-button" type="submit">Carica file selezionati</button>
                      </form>

                      {selectedAlbum && (
                        <div style={selectedAlbumBox}>
                          <strong>Album selezionato:</strong><br />
                          {selectedAlbum.title} · {selectedAlbum.event_year}<br />
                          <span style={mutedText}>Contenuti presenti: {selectedAlbumMedia.length}</span>
                        </div>
                      )}

                      <hr style={dividerStyle} />

                      <h4>Aggiungi link YouTube</h4>
                      <form onSubmit={handleAddYoutubeVideo} style={formStyle}>
                        <input type="url" placeholder="Incolla link YouTube" value={youtubeUrl} onChange={(e) => setYoutubeUrl(e.target.value)} />
                        <button className="primary-auth-button" type="submit">Aggiungi YouTube</button>
                      </form>

                      <hr style={dividerStyle} />

                      <h4>Aggiungi link social</h4>
                      <form onSubmit={handleAddSocialLink} style={formStyle}>
                        <input type="url" placeholder="Incolla link Facebook, Instagram o TikTok" value={socialUrl} onChange={(e) => setSocialUrl(e.target.value)} />
                        <div style={{ display: 'grid', gap: '8px' }}>
                          <label style={mutedText}>Immagine anteprima opzionale</label>
                          <input key={socialPreviewInputKey} type="file" accept="image/*" onChange={(e) => setSocialPreviewFile(e.target.files?.[0] ?? null)} />
                          {socialPreviewFile && <small style={mutedText}>Anteprima selezionata: {socialPreviewFile.name}</small>}
                        </div>
                        <button className="primary-auth-button" type="submit">Aggiungi Social</button>
                      </form>
                    </div>
                  </div>

                  <div style={{ marginTop: '30px' }}>
                    <div style={albumHeaderRow}>
                      <h3 style={{ margin: 0 }}>Album inseriti</h3>
                      <select value={albumYearFilter} onChange={(e) => setAlbumYearFilter(e.target.value)} style={compactSelectStyle}>
                        <option value="all">Tutti gli anni</option>
                        {availableYears.map((year) => <option key={year} value={year}>{year}</option>)}
                      </select>
                    </div>

                    {filteredAlbums.length === 0 && <p style={mutedText}>Non ci sono album per questo filtro.</p>}

                    <div style={compactAlbumList}>
                      {filteredAlbums.map((album) => {
                        const albumMedia = media.filter((item) => item.album_id === album.id)

                        return (
                          <div key={album.id} style={{ display: 'grid', gap: '8px' }}>
                            <article style={{ ...compactAlbumCard, border: selectedAlbumId === album.id ? '1px solid rgba(185,68,79,0.80)' : '1px solid rgba(255,255,255,0.10)' }}>
                              <div style={compactAlbumMain}>
                                {getAdminAlbumCoverUrl(album) ? <img src={getAdminAlbumCoverUrl(album)} alt={album.title} style={compactCoverStyle} /> : <div style={compactCoverPlaceholder}>📁</div>}
                                <div style={{ flex: 1, minWidth: 0 }}>
                                  <h4 style={compactAlbumTitle}>{album.title}</h4>
                                  <p style={compactAlbumMeta}>{album.event_year}{album.event_date ? ` · ${new Date(album.event_date).toLocaleDateString('it-IT')}` : ''}{album.category ? ` · ${album.category}` : ''}{' · '}{album.visible ? 'Visibile' : 'Nascosto'}{' · '}{albumMedia.length} contenuti</p>
                                </div>
                              </div>

                              <div style={compactActionsRow}>
                                <button type="button" className="secondary-auth-button" onClick={() => handleManageAlbumMedia(album)} style={smallAdminButton}>Media</button>
                                <button type="button" className="secondary-auth-button" onClick={() => handleEditAlbum(album)} style={smallAdminButton}>Modifica</button>
                                <button type="button" className="secondary-auth-button" onClick={() => handleToggleAlbumVisible(album)} style={smallAdminButton}>{album.visible ? 'Nascondi' : 'Pubblica'}</button>
                                <button type="button" className="primary-auth-button" onClick={() => handleDeleteAlbum(album.id)} style={smallDangerButton}>Elimina</button>
                              </div>
                            </article>

                            {selectedAlbumId === album.id && (
                              <div style={inlineMediaPanelStyle}>
                                <div style={photoManagerHeader}>
                                  <div>
                                    <h3 style={{ marginBottom: '6px' }}>Contenuti album: {album.title}</h3>
                                    <p style={{ ...mutedText, margin: 0 }}>{album.event_year} · {albumMedia.length} elementi</p>
                                  </div>
                                  <button type="button" className="secondary-auth-button" onClick={() => {
                                    setSelectedAlbumId('')
                                    setGalleryFiles(null)
                                    setYoutubeUrl('')
                                    setSocialUrl('')
                                    setSocialPreviewFile(null)
                                    setGalleryInputKey((prev) => prev + 1)
                                    setSocialPreviewInputKey((prev) => prev + 1)
                                  }} style={smallAdminButton}>Chiudi</button>
                                </div>

                                {albumMedia.length === 0 && <p style={mutedText}>Questo album non contiene ancora media.</p>}
                                {albumMedia.length > 0 && (
                                  <div style={tinyPhotoGrid}>
                                    {albumMedia.map((item) => {
                                      const coverUrl = item.media_type === 'youtube' ? item.thumbnail_url : item.media_type === 'image' ? item.image_url : item.media_type === 'social' ? item.thumbnail_url : null
                                      const isCover = coverUrl && album.cover_image_url === coverUrl
                                      return (
                                        <div key={item.id} style={tinyPhotoCard}>
                                          {renderTinyMediaPreview(item)}
                                          {isCover && <span style={coverBadge}>Cover</span>}
                                          <div style={tinyPhotoActions}>
                                            <button type="button" onClick={() => handleSetCover(item)} style={tinyButton}>Cover</button>
                                            <button type="button" onClick={() => handleDeleteMedia(item)} style={tinyDeleteButton}>X</button>
                                          </div>
                                        </div>
                                      )
                                    })}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </div>
              )}

              {adminTab === 'eventi' && (
                <div>
                  <div style={adminCardStyle}>
                    <h3>{editingEventId ? 'Modifica evento' : 'Crea nuovo evento'}</h3>
                    <form onSubmit={handleSaveEvent} style={formStyle}>
                      <input type="text" placeholder="Titolo evento" value={eventTitle} onChange={(e) => setEventTitle(e.target.value)} />
                      <textarea placeholder="Descrizione evento" value={eventDescription} onChange={(e) => setEventDescription(e.target.value)} rows={5} style={textareaStyle} />
                      <input type="text" placeholder="Luogo evento" value={eventLocation} onChange={(e) => setEventLocation(e.target.value)} />

                      <label style={checkboxLabelStyle}>
                        <input type="checkbox" checked={eventIsProvisional} onChange={(e) => setEventIsProvisional(e.target.checked)} />
                        Data provvisoria
                      </label>

                      {!eventIsProvisional && (
                        <div style={{ display: 'grid', gap: '8px' }}>
                          <label style={mutedText}>Data precisa evento</label>
                          <input type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} />
                        </div>
                      )}

                      {eventIsProvisional && (
                        <div style={eventDateGrid}>
                          <div style={{ display: 'grid', gap: '8px' }}>
                            <label style={mutedText}>Mese provvisorio</label>
                            <select value={eventProvisionalMonth} onChange={(e) => setEventProvisionalMonth(e.target.value)}>
                              <option value="">Seleziona mese</option>
                              <option value="1">Gennaio</option><option value="2">Febbraio</option><option value="3">Marzo</option><option value="4">Aprile</option><option value="5">Maggio</option><option value="6">Giugno</option><option value="7">Luglio</option><option value="8">Agosto</option><option value="9">Settembre</option><option value="10">Ottobre</option><option value="11">Novembre</option><option value="12">Dicembre</option>
                            </select>
                          </div>
                          <div style={{ display: 'grid', gap: '8px' }}>
                            <label style={mutedText}>Anno provvisorio</label>
                            <input type="number" value={eventProvisionalYear} onChange={(e) => setEventProvisionalYear(e.target.value)} />
                          </div>
                        </div>
                      )}

                      <input type="url" placeholder="Link esterno opzionale" value={eventExternalUrl} onChange={(e) => setEventExternalUrl(e.target.value)} />
                      <input type="text" placeholder="Testo pulsante link, es. Iscriviti all’evento" value={eventExternalUrlLabel} onChange={(e) => setEventExternalUrlLabel(e.target.value)} />

                      {existingEventImageUrl && <div><p style={mutedText}>Immagine attuale:</p><img src={existingEventImageUrl} alt="Immagine evento attuale" style={previewImageStyle} /></div>}

                      <div style={{ display: 'grid', gap: '8px' }}>
                        <label style={mutedText}>Immagine evento opzionale</label>
                        <input key={eventImageInputKey} type="file" accept="image/*" onChange={(e) => setEventImageFile(e.target.files?.[0] ?? null)} />
                        {eventImageFile && <small style={mutedText}>File selezionato: {eventImageFile.name}</small>}
                      </div>

                      <div style={{ display: 'grid', gap: '8px' }}>
                        <label style={mutedText}>Documenti evento opzionali</label>
                        <input key={eventDocsInputKey} type="file" multiple accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,image/*" onChange={(e) => setEventDocumentFiles(e.target.files)} />
                        {eventDocumentFiles && eventDocumentFiles.length > 0 && <small style={mutedText}>Documenti selezionati: {eventDocumentFiles.length}</small>}
                      </div>

                      <label style={checkboxLabelStyle}>
                        <input type="checkbox" checked={eventVisible} onChange={(e) => setEventVisible(e.target.checked)} />
                        Evento visibile nel calendario pubblico
                      </label>

                      <div style={actionsRow}>
                        <button className="primary-auth-button" type="submit">{editingEventId ? 'Aggiorna evento' : 'Crea evento'}</button>
                        {editingEventId && <button className="secondary-auth-button" type="button" onClick={resetEventForm}>Annulla modifica</button>}
                      </div>
                    </form>
                  </div>

                  <div style={{ marginTop: '30px' }}>
                    <h3>Eventi inseriti</h3>
                    {events.length === 0 && <p style={mutedText}>Non ci sono ancora eventi inseriti.</p>}
                    <div style={compactAlbumList}>
                      {events.map((event) => (
                        <article key={event.id} style={compactAlbumCard}>
                          <div style={compactAlbumMain}>
                            {(event.signed_image_url || event.image_url) ? <img src={event.signed_image_url || event.image_url || ''} alt={event.title} style={compactCoverStyle} /> : <div style={compactCoverPlaceholder}>📅</div>}
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <h4 style={compactAlbumTitle}>{event.title}</h4>
                              <p style={compactAlbumMeta}>{formatEventDate(event)}{event.location ? ` · ${event.location}` : ''}{' · '}{event.visible ? 'Visibile' : 'Nascosto'}{' · '}{event.event_documents?.length ?? 0} documenti</p>
                            </div>
                          </div>

                          {event.event_documents && event.event_documents.length > 0 && (
                            <div style={eventDocsList}>
                              {event.event_documents.map((doc) => (
                                <div key={doc.id} style={eventDocRow}>
                                  <a href={doc.file_url} target="_blank" rel="noreferrer" style={eventDocLink}>📄 {doc.title}</a>
                                  <button type="button" onClick={() => handleDeleteEventDocument(doc.id)} style={tinyDeleteButton}>X</button>
                                </div>
                              ))}
                            </div>
                          )}

                          <div style={compactActionsRow}>
                            <button type="button" className="secondary-auth-button" onClick={() => handleEditEvent(event)} style={smallAdminButton}>Modifica</button>
                            <button type="button" className="secondary-auth-button" onClick={() => handleToggleEventVisible(event)} style={smallAdminButton}>{event.visible ? 'Nascondi' : 'Pubblica'}</button>
                            <button type="button" className="primary-auth-button" onClick={() => handleDeleteEvent(event.id)} style={smallDangerButton}>Elimina</button>
                          </div>
                        </article>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {adminTab === 'documenti' && <AdminDocumenti />}
              {adminTab === 'insegnanti' && <AdminInsegnanti />}
              {adminTab === 'teoria' && <AdminTeoria />}
              {adminTab === 'iscritti' && <AdminIscritti />}
              {adminTab === 'difesa' && <AdminDifesaPersonale />}
            </section>
          )}

          {!isAdmin && <div style={userInfoBox}><strong>Account user attivo.</strong><br />Ora puoi accedere ai contenuti riservati disponibili per gli utenti registrati.</div>}

          <button style={{ marginTop: '30px' }} className="secondary-auth-button" onClick={handleLogout}>Logout</button>
          {!isAdmin && message && <p style={{ marginTop: '16px' }}>{message}</p>}
        </div>
      </div>
    </>
  )
}

const areaUtenteInlineStyles = `
.primary-auth-button,
.secondary-auth-button {
  border-radius: 999px !important;
  font-weight: 900 !important;
  border: none !important;
}

.primary-auth-button {
  background: linear-gradient(180deg, #b9444f 0%, #82232b 100%) !important;
  color: white !important;
  box-shadow: 0 8px 18px rgba(80, 10, 18, 0.24) !important;
}

.secondary-auth-button {
  background: rgba(255, 255, 255, 0.92) !important;
  color: #111 !important;
}

.primary-auth-button:hover,
.secondary-auth-button:hover {
  opacity: 0.9;
}
`

const dojoBadgeStyle: CSSProperties = {
  width: 'fit-content',
  padding: '6px 12px',
  borderRadius: '999px',
  background: 'linear-gradient(180deg, #b9444f 0%, #82232b 100%)',
  color: 'white',
  fontSize: '12px',
  fontWeight: 900,
  letterSpacing: '0.8px',
  textTransform: 'uppercase',
  boxShadow: '0 8px 18px rgba(80,10,18,0.24)',
}

const authFormStyle: CSSProperties = { display: 'flex', flexDirection: 'column', gap: '14px' }
const authDividerStyle: CSSProperties = { height: '1px', background: 'rgba(255,255,255,0.14)', margin: '24px 0' }
const registerLinkButtonStyle: CSSProperties = { width: '100%', background: 'transparent', border: 'none', color: '#ffffff', fontWeight: 900, cursor: 'pointer', textDecoration: 'underline', fontSize: '15px', padding: '6px 0' }
const adminSectionStyle: CSSProperties = { marginTop: '42px', paddingTop: '32px', borderTop: '1px solid rgba(255,255,255,0.12)' }
const adminLabelStyle: CSSProperties = dojoBadgeStyle
const tabsWrapper: CSSProperties = { display: 'flex', gap: '10px', flexWrap: 'wrap', margin: '22px 0' }
const tabButton = (active: boolean): CSSProperties => ({ padding: '10px 16px', borderRadius: '999px', border: 'none', cursor: 'pointer', fontWeight: 800, background: active ? 'linear-gradient(180deg, #b9444f 0%, #82232b 100%)' : 'rgba(255,255,255,0.10)', color: active ? 'white' : '#d8d8d8', boxShadow: active ? '0 8px 18px rgba(80,10,18,0.24)' : 'none' })
const adminCardStyle: CSSProperties = { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)', borderRadius: '18px', padding: '22px' }
const galleryAdminLayout: CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }
const formStyle: CSSProperties = { display: 'flex', flexDirection: 'column', gap: '14px', marginTop: '18px' }
const twoColumnsStyle: CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px' }
const textareaStyle: CSSProperties = { borderRadius: '12px', padding: '14px', border: '1px solid rgba(255,255,255,0.16)', resize: 'vertical', fontFamily: 'inherit' }
const mutedText: CSSProperties = { color: '#d8d8d8', lineHeight: 1.6 }
const checkboxLabelStyle: CSSProperties = { display: 'flex', alignItems: 'center', gap: '10px', color: '#d8d8d8' }
const actionsRow: CSSProperties = { display: 'flex', gap: '12px', flexWrap: 'wrap', marginTop: '14px' }
const messageBox: CSSProperties = { background: 'rgba(185,68,79,0.18)', border: '1px solid rgba(185,68,79,0.28)', padding: '14px 16px', borderRadius: '14px', color: '#f3dede', marginBottom: '20px' }
const previewImageStyle: CSSProperties = { width: '100%', maxHeight: '240px', objectFit: 'cover', borderRadius: '14px', marginBottom: '12px' }
const selectedAlbumBox: CSSProperties = { marginTop: '18px', padding: '14px', borderRadius: '14px', background: 'rgba(0,0,0,0.18)', color: 'white' }
const dividerStyle: CSSProperties = { border: 'none', borderTop: '1px solid rgba(255,255,255,0.12)', margin: '22px 0' }
const albumHeaderRow: CSSProperties = { display: 'flex', justifyContent: 'space-between', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }
const compactSelectStyle: CSSProperties = { padding: '10px 14px', borderRadius: '999px', border: 'none', fontWeight: 700 }
const compactAlbumList: CSSProperties = { display: 'grid', gap: '8px', marginTop: '16px' }
const compactAlbumCard: CSSProperties = { background: 'rgba(255,255,255,0.06)', borderRadius: '14px', padding: '10px', border: '1px solid rgba(255,255,255,0.10)' }
const compactAlbumMain: CSSProperties = { display: 'flex', gap: '10px', alignItems: 'center' }
const compactCoverStyle: CSSProperties = { width: '56px', height: '56px', objectFit: 'cover', borderRadius: '10px', flexShrink: 0 }
const compactCoverPlaceholder: CSSProperties = { width: '56px', height: '56px', borderRadius: '10px', flexShrink: 0, background: 'rgba(185,68,79,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px' }
const compactAlbumTitle: CSSProperties = { margin: '0 0 3px', fontSize: '15px', lineHeight: 1.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }
const compactAlbumMeta: CSSProperties = { margin: 0, color: '#d8d8d8', fontSize: '12px', lineHeight: 1.35 }
const compactActionsRow: CSSProperties = { display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '8px' }
const smallAdminButton: CSSProperties = { padding: '6px 10px', fontSize: '12px', borderRadius: '999px' }
const smallDangerButton: CSSProperties = { padding: '6px 10px', fontSize: '12px', borderRadius: '999px' }
const inlineMediaPanelStyle: CSSProperties = { background: 'rgba(0,0,0,0.16)', border: '1px solid rgba(185,68,79,0.26)', borderRadius: '14px', padding: '14px' }
const photoManagerHeader: CSSProperties = { display: 'flex', justifyContent: 'space-between', gap: '16px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '18px' }
const tinyPhotoGrid: CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(78px, 1fr))', gap: '8px', marginTop: '16px' }
const tinyPhotoCard: CSSProperties = { position: 'relative', background: 'rgba(0,0,0,0.18)', borderRadius: '10px', padding: '5px', border: '1px solid rgba(255,255,255,0.08)' }
const tinyMediaPreviewWrapper: CSSProperties = { position: 'relative' }
const tinyPhotoImage: CSSProperties = { width: '100%', height: '56px', objectFit: 'cover', borderRadius: '7px', display: 'block', background: '#111' }
const filePreviewStyle: CSSProperties = { width: '100%', height: '56px', borderRadius: '7px', background: 'linear-gradient(135deg, rgba(185,68,79,0.26), rgba(255,255,255,0.10))', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '2px', color: 'white' }
const socialPreviewBadgeStyle: CSSProperties = { position: 'absolute', left: '5px', bottom: '5px', background: 'linear-gradient(180deg, #b9444f 0%, #82232b 100%)', color: 'white', borderRadius: '999px', padding: '3px 6px', fontSize: '9px', fontWeight: 900, maxWidth: 'calc(100% - 10px)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }
const socialPreviewFallbackStyle: CSSProperties = { width: '100%', height: '56px', borderRadius: '7px', background: 'linear-gradient(135deg, rgba(185,68,79,0.26), rgba(255,255,255,0.10))', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '2px', color: 'white' }
const videoBadge: CSSProperties = { position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '16px', fontWeight: 900, textShadow: '0 2px 8px rgba(0,0,0,0.9)' }
const coverBadge: CSSProperties = { position: 'absolute', top: '7px', left: '7px', background: 'linear-gradient(180deg, #b9444f 0%, #82232b 100%)', color: 'white', fontSize: '9px', fontWeight: 800, borderRadius: '999px', padding: '2px 5px' }
const tinyPhotoActions: CSSProperties = { display: 'flex', gap: '4px', marginTop: '5px' }
const tinyButton: CSSProperties = { flex: 1, border: 'none', borderRadius: '7px', padding: '4px 3px', fontSize: '10px', fontWeight: 700, cursor: 'pointer', background: 'white', color: '#111' }
const tinyDeleteButton: CSSProperties = { border: 'none', borderRadius: '7px', padding: '4px 6px', fontSize: '10px', fontWeight: 800, cursor: 'pointer', background: 'linear-gradient(180deg, #b9444f 0%, #82232b 100%)', color: 'white' }
const eventDateGrid: CSSProperties = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '12px' }
const eventDocsList: CSSProperties = { display: 'grid', gap: '6px', marginTop: '10px' }
const eventDocRow: CSSProperties = { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', background: 'rgba(0,0,0,0.16)', padding: '6px 8px', borderRadius: '10px' }
const eventDocLink: CSSProperties = { color: 'white', textDecoration: 'none', fontSize: '12px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }
const userInfoBox: CSSProperties = { marginTop: '32px', padding: '20px', borderRadius: '14px', background: 'rgba(255,255,255,0.06)', color: '#d8d8d8' }

export default AreaUtente
